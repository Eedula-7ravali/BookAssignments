﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace crudApp
{
    public class Book
    {
         int bookId;
         string bookName;
         string AuthorName;
         double Isbn;
         string Description;
         double price;

        public Book(int bookId, string bookName, string authorName, double isbn, string description, double price)
        {
            this.bookId = bookId;
            this.bookName = bookName;
            this.AuthorName = authorName;
            this.Isbn = isbn;
            this.Description = description;
            this.price = price;
        }

        public Book()
        {
        }

        public override string ToString()
        {
            return $"BookId : {bookId}; Book Name : {bookName}; Author : {AuthorName}; ISBN Code : {Isbn}; Price : {price} ";

        }
        public void AddNewBook(List<Book> bList)
        {

            Console.WriteLine("Enter new book Id");
            int Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter new book Name");
            string Name = Console.ReadLine();
            Console.WriteLine("Enter new book Author");
            string Author = Console.ReadLine();
            Console.WriteLine("Enter new book isbn");
            double icode = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter new book description");
            string desc = Console.ReadLine();
            Console.WriteLine("Enter new book price");
            double prc = Convert.ToDouble(Console.ReadLine());

            Book b1 = new Book(Id,Name,Author,icode,desc,prc);
            Console.WriteLine("New book details: " + b1.ToString());
            bList.Add(b1);


        }
        public void EditBook(List<Book> bList)
        {
            Console.WriteLine("Enter the Book Id to edit:");
            int bid = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < bList.Count; i++)
            {
                if (bList[i].bookId == bid)
                {
                    Console.WriteLine("Enter the updated Book Name:");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter the updated Book Author Name:");
                    string author = Console.ReadLine();
                    Console.WriteLine("Enter the updated ISBN Code:");
                    double isb = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter the updated Price:");
                    double price = Convert.ToDouble(Console.ReadLine());

                    bList[i].bookName = name;
                    bList[i].AuthorName = author;
                    bList[i].Isbn = isb;
                    bList[i].price = price;

                    Console.WriteLine("\nUpdated details = " + bList[i].ToString());
                }

            }
        }
        public void DeleteBook(List<Book> bBook)
        {
            Console.WriteLine("Enter BookId to delete");
            int bid = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < bBook.Count; i++)
            {
                if (bBook[i].bookId == bid)
                {
                    bBook.RemoveAt(i);
                }
            }
        }
        public void DescriptionofBook(List<Book> bBook)
        {
            for (int i = 0; i < bBook.Count; i++)
            {
                Console.WriteLine(bBook[i].ToString() +";Description: "+bBook[i].Description);

            }
        }
    }
    internal class Program
    {


        static void Main()
        {
            List<Book> bookList = new List<Book>() {
            new Book(101,"JavaBook", "John",12345,"It is a good Book.",1000),
            new Book(102,"AngularBook", "John",10006,"It is nice.",900),
            new Book(103,".NETBook", "John",12334,"It is a easy to understand Book.",800),
            };
            Book bobj = new Book();
            bool value = true;
            while (value)
            {
              

                Console.WriteLine("1. Add Book");
                Console.WriteLine("2. Display Book");
                Console.WriteLine("3. Edit Book");
                Console.WriteLine("4. Delete Book");
                Console.WriteLine("5.Description");
                Console.WriteLine("6. Exit");

                Console.WriteLine("\nSelect any option:");
                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.WriteLine("Book is Added");
                        bobj.AddNewBook(bookList);
                        break;

                    case 2:
                        Console.WriteLine("Book is Displayed");
                        for (int i = 0; i < bookList.Count; i++)
                        {
                            Console.WriteLine(bookList[i].ToString());
                        }
                        break;
                    case 3:
                        Console.WriteLine("Book is Edited");
                        bobj.EditBook(bookList);
                        break;
                    case 4:
                        bobj.DeleteBook(bookList);
                        Console.WriteLine("Book is Deleted");
                        break;
                    case 5:
                        Console.WriteLine("book description");
                        bobj.DescriptionofBook(bookList);
                        break;

                    case 6:
                        Console.WriteLine("Exit from BookApplication");
                        break;

                    default:
                        Console.WriteLine("Default is Executed");
                        value = false; 
                        break;
                }

            }
            
        }
    }

}
